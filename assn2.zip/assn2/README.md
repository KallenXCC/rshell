ASSIGNMENT 2 
//--------------------------------------------------------------------------------
*This assignment will produce a command shell using C++. It will be called "rshell",
and it will involve many of the common commands found in bash and in the other
programming language: Shell Script. A list of known bugs will periodically be
added to this file as the development proceeds. 

//PROGRAM BUGS
1) Minor compilation issues in relation to classes and its inheritance
[FIXED ON 10/31/2016]

2) strtok() function could not be figured out
[FIXED ON 11/1/2016]

3) execvp() system call was not running
[FIXED ON 11/1/2016]