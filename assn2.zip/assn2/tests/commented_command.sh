#!/bin/sh
#TEST 1
#ls -l

#TEST 2
#ECHO PING SING BLING DING

#TEST 3
#ls -a

#TEST 4
ECHO BEFORE #date ECHO AFTER

#TEST 5
ECHO CURRENT: #zdump EST

#TEST 6
ECHO CURRENT: #zdump PST

#TEST 7
#time ls -l

#TEST 8
#touch README.md

#TEST 9
#cal

#TEST 10
#git status