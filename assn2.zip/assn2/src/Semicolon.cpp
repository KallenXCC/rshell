#include "../header/Semicolon.h"

int Semicolon::execute() {
    return current->execute();
}