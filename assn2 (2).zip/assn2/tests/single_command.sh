#!/bin/sh
#TEST 1
ls -l

#TEST 2
ls -a

#TEST 3
ls -a -l

#TEST 4
mkdir testing

#TEST 5
touch README.md test.cpp test.txt

#TEST 6
cat README.md

#TEST 7
man g++

#TEST 8
find

#TEST 9
ECHO a b c d e f g h i j k l m n o p q r s t u v w x y z

#TEST 10
git status