#ifndef PRECEDENCE_H
#define PRECEDENCE_H

class Precedence

#endif

/* Notes on the class:
*It will contain one stack. This will be used to keep track of all of the 
commands in the parentheses. Then the top of the stack (which will be holding)